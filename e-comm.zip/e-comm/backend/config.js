const mongoose = require('mongoose')

try {
    mongoose.connect('mongodb://localhost:27017/e-comm')
    console.log("database contect");
} catch (error) {
    console.log(error)
}