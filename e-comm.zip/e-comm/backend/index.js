// app.js
const express = require('express');
const app = express();
const port = 5000;
const bodyParser = require('body-parser');
const cors = require('cors');
const { MongoClient, ObjectId } = require('mongodb');
require('./config');
const url = 'mongodb://localhost:27017';

// const client = new MongoClient(url, { useNewUrlParser: true, useUnifiedTopology: true });
// const dbName = 'e-comm'
//models
const products = require('./model/product');
const userDatas = require('./model/data');
const carts = require('./model/cart');

app.use(bodyParser.json());
app.use(cors());

app.get('/api', async (req, res) => {
    try {
        let result = await products.find();

        res.send(result);
    } catch (error) {
        res.status(200).json({ error: true });
    }
});

app.get('/api/:id', async (req, res) => {

    try {
        let result = await products.findOne({ _id: req.params.id });

        res.send(result);
    } catch (error) {
        res.status(200).json({ error: true });
    }
});

app.post('/api/postData', async (req, res) => {

    try {
        let { url, company, image, name, discount, price, size, resolution, os, graphics, ssd, ram, processor } = req.body;
        let result = new products({ url, company, image, name, discount, price, size, resolution, os, graphics, ssd, ram, processor });
        console.log(result);

        await result.save();
        res.status(200).send('Data received successfully');
    } catch (error) {

        res.status(200).json({ error: true });
    }

});

app.put('/api/putData/:id', async (req, res) => {
    try {
        await products.updateOne(
            { _id: req.params.id }, {
            $set: req.body
        }
        );
        console.log(req.body);
        res.send("Data update successfully")
    } catch (error) {
        res.status(200).json({ error: true });
    }
});

app.delete('/api/delete/:id', async (req, res) => {
    // const id = req.params.id;
    // console.log(id);

    console.log(req.params.id);

    try {
        const result = await products.deleteOne({ _id: new ObjectId(req.params.id) });
        console.log(req.params.id);

        if (result.deletedCount === 1) {
            res.json({ message: 'Record deleted successfully' });
        } else {
            res.status(404).json({ message: 'Record not found' });
        }
    } catch (error) {
        console.error('Error deleting document:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});


// SignUp Page Backend

app.get('/login/:email/:passwrod', async (req, res) => {
    console.log(req.body);
    try {
        let result = await userDatas.findOne({ email: req.params.email, pass: req.params.passwrod });

        if (result) {
            res.status(200).json({ message: "successfully login" });
        } else {
            res.status(200).json({ message: "email or password invalid" });
        }
    } catch (error) {
        res.status(200).json({ error: true });
    }
});

app.post('/signUp', async (req, res) => {
    console.log(req.body);
    try {
        let { firstname, lastname, email, pass } = req.body;
        let result = new userDatas({ firstname, lastname, email, pass });
        console.log(result);

        if(result != null) {
            await result.save();
            res.status(200).send('Data received successfully');
        }else{
            res.status(200).send('Data not received successfully');
        }

    } catch (error) {

        res.status(200).json({ error: true });
    }

});


// Add To Cart Api

app.get('/cartProduct', async (req, res) => {
    try {
        let result = await carts.find();

        res.send(result);
    } catch (error) {
        res.status(200).json({ error: true });
    }
});

app.post('/cartProduct/postdata', async (req, res) => {
    console.log(req.body);
    try {
        let { url, company, image, name, discount, price, size, resolution, os, graphics, ssd, ram, processor } = req.body;
        let result = new carts({ url, company, image, name, discount, price, size, resolution, os, graphics, ssd, ram, processor });
        console.log(result);

        await result.save();
        res.status(200).send('Data received successfully');
    } catch (error) {

        res.status(200).json({ error: true });
    }

});

app.delete('/cartProduct/Delete/:id', async (req, res) => {
    // const id = req.params.id;
    // console.log(id);

    console.log(req.params.id);

    try {
        const result = await carts.deleteOne({ _id: new ObjectId(req.params.id) });
        console.log(req.params.id);

        if (result.deletedCount === 1) {
            res.json({ message: 'Record deleted successfully' });
        } else {
            res.status(404).json({ message: 'Record not found' });
        }
    } catch (error) {
        console.error('Error deleting document:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
