import React from 'react'
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import Swal from 'sweetalert2'

export default function AdminSite() {

    const navigate = useNavigate();
    const Swal = require('sweetalert2');

    const [data, setData] = useState({
        url: '',
        company: '',
        image: '',
        name: '',
        discount: '',
        price: "",
        size: '',
        resolution: '',
        os: '',
        graphics: '',
        ssd: '',
        ram: '',
        processor: '',
    });
    return (
        <div className='container mt-4'>
            <div className='row'>   

            {/* <div className='row'> */}
                <div className='col'>
                    {/* <label> */}
                        url:
                        <input type="text" className="form-control" onChange={(e) => {
                            setData({ ...data, url: e.target.value });
                        }} />
                    {/* </label> */}
                </div>
            </div>

            <br />

            <div className='row'>
                <div className='col'>
                    {/* <label> */}
                        Company:
                        <input type="text" className="form-control" onChange={(e) => {
                            setData({ ...data, company: e.target.value });
                        }} />
                    {/* </label> */}
                </div>
            {/* </div> */}

            {/* <div className='row'> */}
                <div className='col'>
                    {/* <label> */}
                        Image:
                        <input type="text" className="form-control" onChange={(e) => {
                            setData({ ...data, image: e.target.value });
                        }} />
                    {/* </label> */}
                </div>
            </div>

            <br />

            <div className='row'>
                <div className='col'>
                    {/* <label> */}
                        Name:
                        <input type="text" className="form-control" onChange={(e) => {
                            setData({ ...data, name: e.target.value });
                        }} />
                    {/* </label> */}
                </div>
            {/* </div> */}

            {/* <div className='row'> */}
                <div className='col'>
                    {/* <label> */}
                        Discount:
                        <input type="number" className="form-control" onChange={(e) => {
                            setData({ ...data, discount: e.target.value });
                        }} />
                    {/* </label> */}
                </div>
            </div>

            <br />

            <div className='row'>
                <div className='col'>
                    {/* <label> */}
                        Price:
                        <input type="number" className="form-control" onChange={(e) => {
                            setData({ ...data, price: e.target.value });
                        }} />
                    {/* </label> */}
                </div>
            {/* </div> */}

            {/* <div className='row'> */}
                <div className='col'>
                    {/* <label> */}
                        Size:
                        <input type="text" className="form-control" onChange={(e) => {
                            setData({ ...data, size: e.target.value });
                        }} />
                    {/* </label> */}
                </div>
            </div>

            <br />

            <div className='row'>
                <div className='col'>
                    {/* <label> */}
                        Resolution:
                        <input type="text" className="form-control" onChange={(e) => {
                            setData({ ...data, resolution: e.target.value });
                        }} />
                    {/* </label> */}
                </div>
            {/* </div> */}

            {/* <div className='row'> */}
                <div className='col'>
                    {/* <label> */}
                        OS:
                        <input type="text" className="form-control" onChange={(e) => {
                            setData({ ...data, os: e.target.value });
                        }} />
                    {/* </label> */}
                </div>
            </div>

            <br />

            <div className='row'>
                <div className='col'>
                    {/* <label> */}
                        Graphics:
                        <input type="text" className="form-control" onChange={(e) => {
                            setData({ ...data, graphics: e.target.value });
                        }} />
                    {/* </label> */}
                </div>
            {/* </div> */}

            {/* <div className='row'> */}
                <div className='col'>
                    {/* <label> */}
                        SSD:
                        <input type="text" className="form-control" onChange={(e) => {
                            setData({ ...data, ssd: e.target.value });
                        }} />
                    {/* </label> */}
                </div>
            </div>

            <br />

            <div className='row'>
                <div className='col'>
                    {/* <label> */}
                        RAM:
                        <input type="text" className="form-control" onChange={(e) => {
                            setData({ ...data, ram: e.target.value });
                        }} />
                    {/* </label> */}
                </div>
            {/* </div> */}

            {/* <div className='row'> */}
                <div className='col'>
                    {/* <label> */}
                        Processor:
                        <input type="text" className="form-control" onChange={(e) => {
                            setData({ ...data, processor: e.target.value });
                        }} />
                    {/* </label> */}
                </div>
            </div>

            <div className='row mt-4 mb-4'>
                <div className='col d-flex justify-content-center'>
                    <input type="button" className='btn btn-success' value="Add Product" onClick={() => {

                        fetch('http://localhost:5000/api/postData', {
                            method: "POST",
                            body: JSON.stringify(data),
                            headers: {
                                "Content-Type": "application/json"
                            }
                        })
                            .then((response) => {
                                if (response.ok) {
                                    return response.text();
                                }
                                throw new Error('Network response was not ok.');
                            })
                            .then((data) => {
                                Swal.fire({
                                    position: "top-end",
                                    icon: "success",
                                    title: "Record Added!",
                                    showConfirmButton: false,
                                    timer: 1500,
                                });
                                navigate('/admin/update/listcard');
                                console.log('Response:', data);
                            })
                            .catch((error) => {
                                console.error('Error:', error);
                            });
                    }} />
                </div>
            </div>
        </div>
    );
}
