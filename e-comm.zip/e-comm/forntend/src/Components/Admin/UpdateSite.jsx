import React from 'react'
import { useNavigate, useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';

export default function UpdateSite() {

    const param = useParams();
    const navigate = useNavigate();
    const apiUrl = "http://localhost:5000/api";

    const [data, setData] = useState({});


    useEffect(() => {
        fetch(apiUrl + "/" + param.id, { method: "GET" })
            .then(res => res.json())
            .then(res => setData(res));
        // .then(res =>console.log(res));
    }, []);

    return (<>
        <div className='container mt-4'>
            <div className='row'>
                <div className='col'>
                    {/* <label> */}
                    url:
                    <input type="text" value={data.url} className="form-control" onChange={(e) => {
                        setData({ ...data, url: e.target.value });
                    }} />
                    {/* </label> */}
                </div>
            </div>

            <br />

            <div className='row'>
                <div className='col'>
                    {/* <label> */}
                    Company:
                    <input type="text" value={data.company} className="form-control" onChange={(e) => {
                        setData({ ...data, company: e.target.value });
                    }} />
                    {/* </label> */}
                </div>
                {/* </div> */}

                {/* <div className='row'> */}
                <div className='col'>
                    {/* <label> */}
                    Image:
                    <input type="text" value={data.image} className="form-control" onChange={(e) => {
                        setData({ ...data, image: e.target.value });
                    }} />
                    {/* </label> */}
                </div>
            </div>

            <br />

            <div className='row'>
                <div className='col'>
                    {/* <label> */}
                    Name:
                    <input type="text" value={data.name} className="form-control" onChange={(e) => {
                        setData({ ...data, name: e.target.value });
                    }} />
                    {/* </label> */}
                </div>
                {/* </div> */}

                {/* <div className='row'> */}
                <div className='col'>
                    {/* <label> */}
                    Discount:
                    <input type="number" value={data.discount} className="form-control" onChange={(e) => {
                        setData({ ...data, discount: e.target.value });
                    }} />
                    {/* </label> */}
                </div>
            </div>

            <br />

            <div className='row'>
                <div className='col'>
                    {/* <label> */}
                    Price:
                    <input type="text" value={data.price} className="form-control" onChange={(e) => {
                        setData({ ...data, price: e.target.value });
                    }} />
                    {/* </label> */}
                </div>
                {/* </div> */}

                {/* <div className='row'> */}
                <div className='col'>
                    {/* <label> */}
                    Size:
                    <input type="text" value={data.size} className="form-control" onChange={(e) => {
                        setData({ ...data, size: e.target.value });
                    }} />
                    {/* </label> */}
                </div>
            </div>

            <br />

            <div className='row'>
                <div className='col'>
                    {/* <label> */}
                    Resolution:
                    <input type="text" value={data.resolution} className="form-control" onChange={(e) => {
                        setData({ ...data, resolution: e.target.value });
                    }} />
                    {/* </label> */}
                </div>
                {/* </div> */}

                {/* <div className='row'> */}
                <div className='col'>
                    {/* <label> */}
                    OS:
                    <input type="text" value={data.os} className="form-control" onChange={(e) => {
                        setData({ ...data, os: e.target.value });
                    }} />
                    {/* </label> */}
                </div>
            </div>

            <br />

            <div className='row'>
                <div className='col'>
                    {/* <label> */}
                    Graphics:
                    <input type="text" value={data.graphics} className="form-control" onChange={(e) => {
                        setData({ ...data, graphics: e.target.value });
                    }} />
                    {/* </label> */}
                </div>
                {/* </div> */}

                {/* <div className='row'> */}
                <div className='col'>
                    {/* <label> */}
                    SSD:
                    <input type="text" value={data.ssd} className="form-control" onChange={(e) => {
                        setData({ ...data, ssd: e.target.value });
                    }} />
                    {/* </label> */}
                </div>
            </div>

            <br />

            <div className='row'>
                <div className='col'>
                    {/* <label> */}
                    RAM:
                    <input type="text" value={data.ram} className="form-control" onChange={(e) => {
                        setData({ ...data, ram: e.target.value });
                    }} />
                    {/* </label> */}
                </div>
                {/* </div> */}

                {/* <div className='row'> */}
                <div className='col'>
                    {/* <label> */}
                    Processor:
                    <input type="text" value={data.processor} className="form-control" onChange={(e) => {
                        setData({ ...data, processor: e.target.value });
                    }} />
                    {/* </label> */}
                </div>
            </div>

            <div className='row mt-4 mb-4'>
                <div className='col d-flex justify-content-center'>
                    <input type="button" className='btn btn-primary' value="Edit Product" onClick={() => {

                        fetch("http://localhost:5000/api/putData" + "/" + param.id, {
                            method: "PUT",
                            body: JSON.stringify(data),
                            headers: {
                                "Content-Type": "application/json"
                            }
                        })
                            .then((res) => {
                                //console.log(res);
                                navigate('/admin/update/listcard');
                            })
                    }} />
                </div>
            </div>
        </div>
    </>);
}