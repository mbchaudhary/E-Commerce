import React from "react";
import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";

const Card_Detail = () => {

    const navigate = useNavigate();
    const param = useParams();

    const [data, setData] = useState({});

    const [prod, setprod] = useState({
        _id: '',
        url: '',
        company: '',
        image: '',
        name: '',
        discount: '',
        price: "",
        size: '',
        resolution: '',
        os: '',
        graphics: '',
        ssd: '',
        ram: '',
        processor: '',
    });

    // setprod({...data});

    // console.log(prod);

    useEffect(() => {
        fetch("http://localhost:5000/api" + "/" + param.id, { method: "GET" })
            .then(res => res.json())
            .then(res => setData(res));
    }, []);

    useEffect(()=>{
        setprod({...data});
    })

    return (

        <div class="container">
            <div class="row mt-3">
                <div class="col-md-6">
                    <div class="product">
                        <img src={data.image} class="img-fluid" alt="Product Image" width={'80%'} />
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="product product-info">
                        <h2>{data.name}</h2>
                        <p>
                            <ui>
                                <li>
                                    {data.size}
                                </li>
                                <li>
                                    {data.resolution}
                                </li>
                                <li>
                                    {data.os}
                                </li>
                                <li>
                                    {data.graphics}
                                </li>
                                <li>
                                    {data.processor}
                                </li>
                                <li>
                                    {data.ssd}
                                </li>
                                <li>
                                    {data.ram}
                                </li>
                            </ui>
                        </p>
                        <p class="price">Price: ₹{data.price}</p>
                        <p class="price">Discount: {data.discount}%</p>
                        <button class="btn btn-primary" onClick={() => {
                            console.log("Product data:",data);
                            console.log("Product Cart:", prod);
                            fetch('http://localhost:5000/cartProduct/postdata', {
                                method: "POST",
                                body: JSON.stringify(prod),
                                headers: {
                                    "Content-Type": "application/json"
                                }
                            })
                                .then((response) => {
                                    if (response.ok) {
                                        return response.text();
                                    }
                                    throw new Error('Network response was not ok.');
                                })
                                .then((prod) => {
                                    // Swal.fire({
                                    //     position: "top-end",
                                    //     icon: "success",
                                    //     title: "Record Added!",
                                    //     showConfirmButton: false,
                                    //     timer: 1500,
                                    // });
                                    // navigate('/admin/update/listcard');
                                    console.log('Response:', prod);
                                    navigate('/addTocart');
                                })
                                .catch((error) => {
                                    console.error('Error:', error);
                                });
                        }}>Add to Cart</button>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="product">
                        <h3>Product Details</h3>
                        <p>More details about the product...</p>
                    </div>
                </div>
            </div>
        </div >
    )
};

export default Card_Detail;