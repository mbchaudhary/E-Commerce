import React from 'react'
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Cart.css'

export default function Card() {

    const [data, setData] = useState([]);

    useEffect(() => {
        fetch("http://localhost:5000/api")
            .then(res => res.json())
            .then(res => setData(res));
    }, []);


    const result = data.map((e, index) => {
        return (
            // <Link to={}>
            <div className='col mt-4'>
                <div className="card" style={{ width: "18rem"}}>
                    <img src={e.image} className="card-img-top" alt="..." />
                    <div className="card-body">
                        <h5 className="card-title">{e.name}</h5>
                        <p className="card-text">{e.discribtion}</p>
                        <div className='row'>
                            <div className='col'>
                                <a href="#" className="btn btn-primary">Buy Now</a>
                            </div>
                            <div className='col'>
                                <a href={e.url} className="btn btn-primary">Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            // </Link>
        );
    })
    return (
        <>
            <div className='container mb-4'>
                <div className='row'>
                    <div className='col mt-5 text-success'>
                        <h3>20% Discount</h3>
                    </div>
                </div>
                <div className='row'>
                    {result}
                </div>
            </div>
        </>
    );
};