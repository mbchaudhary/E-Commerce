import React from 'react'
import './style.css';

export default function UserProfile() {
    return (
        <div>
            <div class="navbar-top">
                <div class="title">
                    <h1>Profile</h1>
                </div>
            </div>

            <div class="sidenav">
                <div class="profile">
                    <img src="https://imdezcode.files.wordpress.com/2020/02/imdezcode-logo.png" alt="" width="100" height="100" />

                        <div class="name">
                            ImDezCode
                        </div>
                        <div class="job">
                            Web Developer
                        </div>
                </div>

                <div class="sidenav-url">
                    <div class="url">
                        <a href="#profile" class="active">Profile</a>
                        <hr align="center" />
                    </div>
                    <div class="url">
                        <a href="#settings">Settings</a>
                        <hr align="center" />
                    </div>
                </div>
            </div>

            <div class="main">
                <h2>IDENTITY</h2>
                <div class="card">
                    <div class="card-body">
                        <i class="fa fa-pen fa-xs edit"></i>
                        <table>
                            <tbody>
                                <tr>
                                    <td>Name</td>
                                    <td>:</td>
                                    <td>ImDezCode</td>
                                </tr>
                                <tr>
                                    <td>Email</td>
                                    <td>:</td>
                                    <td>imdezcode@gmail.com</td>
                                </tr>
                                <tr>
                                    <td>Address</td>
                                    <td>:</td>
                                    <td>Bali, Indonesia</td>
                                </tr>
                                <tr>
                                    <td>Hobbies</td>
                                    <td>:</td>
                                    <td>Diving, Reading Book</td>
                                </tr>
                                <tr>
                                    <td>Job</td>
                                    <td>:</td>
                                    <td>Web Developer</td>
                                </tr>
                                <tr>
                                    <td>Skill</td>
                                    <td>:</td>
                                    <td>PHP, HTML, CSS, Java</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <h2>SOCIAL MEDIA</h2>
                <div class="card">
                    <div class="card-body">
                        <i class="fa fa-pen fa-xs edit"></i>
                        <div class="social-media">
                            <span class="fa-stack fa-sm">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fab fa-facebook fa-stack-1x fa-inverse"></i>
                            </span>
                            <span class="fa-stack fa-sm">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fab fa-twitter fa-stack-1x fa-inverse"></i>
                            </span>
                            <span class="fa-stack fa-sm">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fab fa-instagram fa-stack-1x fa-inverse"></i>
                            </span>
                            <span class="fa-stack fa-sm">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fab fa-invision fa-stack-1x fa-inverse"></i>
                            </span>
                            <span class="fa-stack fa-sm">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fab fa-github fa-stack-1x fa-inverse"></i>
                            </span>
                            <span class="fa-stack fa-sm">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fab fa-whatsapp fa-stack-1x fa-inverse"></i>
                            </span>
                            <span class="fa-stack fa-sm">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fab fa-snapchat fa-stack-1x fa-inverse"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
