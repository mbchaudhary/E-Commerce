import React from 'react'
import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { MdDelete } from "react-icons/md";
import Swal from 'sweetalert2'

export default function AddProduct() {

    const Swal = require('sweetalert2');

    const navigate = useNavigate();
    const apiUrl = "http://localhost:5000/cartProduct";

    const [data, setData] = useState([]);

    useEffect(() => {
        fetch(apiUrl)
            .then(res => res.json())
            .then(res => setData(res));
    }, []);

    const addCart = data.map((e) => {
        return (
            <div class="container m-5">
                <h1>Add to Cart</h1>
                <div class="product">
                    <div class="row">
                        <div class="col-md-2">
                            <img src={e.image} class="img-fluid" alt="Product Image" />
                        </div>
                        <div class="col-md-7 product-info">
                            <h2>{e.name}</h2>
                            <p>
                                <ul>
                                    <li>
                                        {e.graphics}
                                    </li>
                                    <li>
                                        {e.processor}
                                    </li>
                                </ul>
                            </p>
                        </div>
                        <div class="col-md-3 product-info">
                            <h6 class="price">Price: ₹{e.price}</h6>
                            <h6 class="price">Discount: {e.discount}%</h6>
                            <div class="input-group">
                                <button class="btn btn-outline-secondary" type="button">-</button>
                                <input type="text" class="form-control" value="1" />
                                <button class="btn btn-outline-secondary" type="button">+</button>
                            </div>
                            <button class="btn btn-primary m-3">Add to Cart</button>
                            <button class="btn btn-danger m-3" onClick={() => {
                                fetch("http://localhost:5000/cartProduct/Delete" + "/" + e._id, { method: "DELETE" })
                                    .then(res => {
                                        Swal.fire({
                                            position: "top-end",
                                            icon: "success",
                                            title: "Record Deleted!",
                                            showConfirmButton: false,
                                            timer: 1500
                                        });
                                    });

                                console.log(e._id);
                            }}><MdDelete /></button>
                        </div>
                    </div>
                </div>
            </div>
        );
    })

    return (
        <div className='container'>
            <div className='row'>
                <div className='col'>
                    {addCart}
                </div>
            </div>
        </div>
    );
}
