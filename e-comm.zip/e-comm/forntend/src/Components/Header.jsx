import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import './Style.css';

export default function Header() {

    const [searchBar, setsearchBar] = useState('');

    return (
        <div className='header'>
            <nav className="navbar navbar-expand-lg bg-white">
                <div className="container-fluid">
                    <a className="navbar-brand text-black" href="#">Navbar</a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <Link className="nav-link active text-black" aria-current="page" to="/">Home</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link text-black" to="/shopping">Shopping</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/addTocart' className="nav-link text-black" aria-disabled="true">Cart</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link text-black" aria-disabled="true" to="/login">Admin</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link text-black" to="/Profile">Profile</Link>
                            </li>
                        </ul>
                        <form className="d-flex" role="search">
                            <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" onChange={(e)=>setsearchBar(e.target.value)} />
                                <button className="btn btn-outline-success" onClick={()=>{
                                    console.log(searchBar);
                                }}>Search</button>
                        </form>
                    </div>
                </div>
            </nav>
        </div>
    )
}