import './App.css';
import Home from './Screens/Home';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Shopping from './Screens/Shopping';
import CardDetails from './Screens/CardDetails';
import ServerSite from './Screens/ServerSite';
import Card_List from './Screens/Card_List';
import UpdateSite from './Components/Admin/UpdateSite';
import Login from './Login&SignUp/Login'
import SignUp from './Login&SignUp/SignUp';
import Add_Cart from './Screens/Add_Cart';
import Profile_Detail from './Screens/Profile_Detail';
  
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/login' element={<Login />} />
          <Route path='/signUp' element={<SignUp />} />
          <Route path='/' element={<Home />} />
          <Route path='/shopping' element={<Shopping />} />
          <Route path='/cardDetail' element={<CardDetails />} />
          <Route path='/cardView/:id' element={<CardDetails />} />
          <Route path='/admin/add' element={<ServerSite />} />
          <Route path='/admin/update/listcard' element={<Card_List />} />
          <Route path='/admin/update/card/:id' element={<UpdateSite />} />
          <Route path='/addTocart' element={<Add_Cart />} />
          <Route path='/Profile' element={<Profile_Detail />} />
          {/* <Route path='/admin/update/:id' element={<ServerSiteUpdate />}/> */}
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
