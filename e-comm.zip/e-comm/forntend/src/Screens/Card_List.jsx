import React from 'react'
import Footer from '../Components/Footer'
import NavBar from '../Components/Admin/NavBar'
import ListCard from '../Components/Admin/ListCard'

export default function Card_List() {
    return (
        <>
            <div>
                <NavBar />
            </div>
            <div>
                <ListCard />
            </div>
            <div>
                <Footer />
            </div>
        </>
    )
}
