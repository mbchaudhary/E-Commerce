import React from 'react'
import Header from '../Components/Header'
import Footer from '../Components/Footer'
import Card_List from '../Components/CardList'

export default function Shopping() {
    return (
        <>
            <div>
                <Header />
            </div>
            <div>
                <Card_List />
            </div>
            <div>
                <Footer />
            </div>
        </>
    )
}
